# platzi-curso-practico-javascript

...

## Taller #1: figuras geométricas

- Primer paso: definir las fórmulas
- Segundo paso: implementar la fórmulas en JavaScript 
- Tercer paso: crear funciones
- Cuarto paso: integrar JS con HTML

## Taller #2: porcentaajes y descuentos

- Primer paso: definir las fórmulas
- Segundo paso: implementar la fórmulas en JavaScript 
- Tercer paso: crear funciones
- Cuarto paso: integrar JS con HTML

## Taller #3: promedio, mediana y moda

- Primer paso: definir las fórmulas
- Segundo paso: implementar la fórmulas en JavaScript 
- Tercer paso: crear funciones
- Cuarto paso: integrar JS con HTML
# curso-practico-javascript
